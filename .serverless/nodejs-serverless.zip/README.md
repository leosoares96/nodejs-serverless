"# nodejs-serverless"

### Comando para criação do projeto com template nodejs

serverless create --template aws-nodejs --path nodejs-serverless

### Configuração da chave de acesso da AWS obtida em IAM

serverless config credentials --provider aws --key=xxx --secret xxx
